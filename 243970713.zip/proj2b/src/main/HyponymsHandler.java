package main;
import browser.NgordnetQuery;
import browser.NgordnetQueryHandler;

import java.util.Collections;
import java.util.List;

public class HyponymsHandler extends NgordnetQueryHandler {
    private WordNet wordNet;

    public HyponymsHandler(String synsetsFile, String hyponymsFile) {
        this.wordNet = new WordNet(synsetsFile, hyponymsFile);
    }

    @Override
    public String handle(NgordnetQuery query) {
        List<String> words = query.words();
        List<String> hyponyms;

        if (words.size() == 1) {
            String word = words.get(0);
            hyponyms = wordNet.getTheHyponyms(word);
        } else {
            hyponyms = wordNet.commonHyponyms(words);
        }
        Collections.sort(hyponyms);
        return hyponyms.toString();
    }
}
