package main;
import java.util.*;
import edu.princeton.cs.algs4.In;



public class WordNet {
    private Map<String, Set<Integer>> wordToSynsetIds;
    private Map<Integer, Set<String>> synsetIdToWords;
    private Map<Integer, Set<Integer>> hyponymsGraph;

    public WordNet(String synsetsFile, String hyponymsFile) {
        wordToSynsetIds = new HashMap<>();
        synsetIdToWords = new HashMap<>();
        hyponymsGraph = new HashMap<>();

        // Filereademo
        //note: similar parsing implementation as proj2a
        In synsetsList = new In(synsetsFile);
        while (!synsetsList.isEmpty()) {
            String synsetLine = synsetsList.readLine();
            String[] synsetArray = synsetLine.split(",");
            int synsetId = Integer.parseInt(synsetArray[0]);
            String[] words = synsetArray[1].split(" ");

            for (String word : words) {
                if (!wordToSynsetIds.containsKey(word)) { //incase that word is not there so we can avoid the null error
                    wordToSynsetIds.put(word, new HashSet<Integer>());
                }
                Set<Integer> synsetIds = wordToSynsetIds.get(word);
                synsetIds.add(synsetId);
                wordToSynsetIds.put(word, synsetIds);
            }

            synsetIdToWords.put(synsetId, new HashSet<>(Arrays.asList(words)));
        }

        In hyponymsList = new In(hyponymsFile);
        while (!hyponymsList.isEmpty()) {
            String hyponymsLine = hyponymsList.readLine();
            String[] hyponymsArray = hyponymsLine.split(",");
            int synsetId = Integer.parseInt(hyponymsArray[0]);

            for (int i = 1; i < hyponymsArray.length; i++) {
                if (!hyponymsGraph.containsKey(synsetId)) {
                    hyponymsGraph.put(synsetId, new HashSet<>());
                }

                int hyponymId = Integer.parseInt(hyponymsArray[i]);
                Set<Integer> hyponyms = hyponymsGraph.get(synsetId);
                hyponyms.add(hyponymId);
                hyponymsGraph.put(synsetId, hyponyms);
            }
        }
    }

    public List<String> getTheHyponyms(String word) {
        Set<String> hyponyms = new TreeSet<>();
        Set<Integer> synsetIds = wordToSynsetIds.get(word);


        if (synsetIds != null) {
            for (int synsetId : synsetIds) {
                collectHyponyms(synsetId, hyponyms);
            }
        }

        return new ArrayList<>(hyponyms);
    }
    //https://www.geeksforgeeks.org/collections-addall-method-in-java-with-examples/
    private void collectHyponyms(int synsetId, Set<String> hyponyms) {
        Set<String> words = synsetIdToWords.get(synsetId);

        hyponyms.addAll(words);

        Set<Integer> childSynsetIds = hyponymsGraph.get(synsetId);

        if (childSynsetIds != null) {
            for (int childSynsetId : childSynsetIds) {
                collectHyponyms(childSynsetId, hyponyms);
            }
        }
    }

    public List<String> commonHyponyms(List<String> words) {
        Set<String> commonHyponyms = new HashSet<>();

        if (!words.isEmpty()) {
            commonHyponyms.addAll(getTheHyponyms(words.get(0)));

            for (int i = 1; i < words.size(); i++) {
                String word = words.get(i);
                Set<String> hyponyms = new HashSet<>(getTheHyponyms(word));
                commonHyponyms.retainAll(hyponyms);
            }
        }
        //https://www.programiz.com/java-programming/library/arraylist/retainall#:~:text=The%20syntax%20of%20the%20retainAll,object%20of%20the%20ArrayList%20class.
        List<String> sortedCommonHyponyms = new ArrayList<>(commonHyponyms);
        Collections.sort(sortedCommonHyponyms);
        return sortedCommonHyponyms;
    }
}

